from flask import Flask,render_template,request,redirect,jsonify
from pymongo import MongoClient
from bson.json_util import dumps

app=Flask(__name__)

client=MongoClient('mongodb://localhost:27017')
db=client['Food_calories_tracker']
collections=db['Tracker']
@app.route('/')
def start_page():
    return render_template('index.html')

@app.route('/add',methods=['GET','POST'])
def add_page():

    if request.method=='POST':
        
        date1=request.form['date']
        item=request.form['food']
        fat=float(request.form['fat'])
        protein=float(request.form['protein'])
        carbo=float(request.form['carbo'])
        calorie=4*carbo+4*protein+9*fat
        mydict={"food":item,'fat':fat,'protein':protein,'carbo':carbo,'calorie':calorie,'date':date1}
        collections.insert_one(mydict)
        return redirect('/home')
        
    return render_template('add.html')

@app.route('/update/',methods=['GET','POST'])
def update_page():

    if request.method=='POST':
        date=request.form['date']
        item=request.form['food']
    
    stud =collections.find()
    return render_template('update.html',foods=stud)


@app.route('/home',methods=['GET','POST'])

def home_page():

    if request.method=='POST':
        date1=request.form['date']
        item=collections.find({'date':date1})
        return render_template('home.html',foods=item)
    
    item=collections.find().sort('date',-1)
    return render_template('home.html',foods=item)


@app.route('/home/<string:date>',methods=['DELETE'])
def delete(date):
    collections.delete_many({'date':date})
    return jsonify({'result':'True'})


@app.route("/home/<string:date1>/<string:food_name>",methods=['PUT'])
def update(date1,food_name):
    collections.update_one({'date':date1,'food':food_name},{'$set':{'calorie':50}})
    item=collections.find({'date':date1,'food':food_name})
    item1=dumps(list(item),indent=2)
    return jsonify(item1)

@app.route("/update/<string:date>/<string:food>",methods=['GET','POST'])
def update_food(date,food):
    if request.method=='POST':
        date1=request.form['date']
        item=request.form['food']
        fat=float(request.form['fat'])
        protein=float(request.form['protein'])
        carbo=float(request.form['carbo'])
        calorie=4*carbo+4*protein+9*fat
        collections.update_one({'date':date1,'food':item},{'$set':{'food':item,'fat':fat,'protein':protein,
        'carbo':carbo,'calorie':calorie,'date':date1}})
        return redirect('/home')

    all=collections.find({'date':date,'food':food})
    return render_template('update.html',foods=all)

@app.route("/delete/<string:date>/<string:food>",methods=['GET'])
def delete_food(date,food):
    collections.delete_one({'date':date,'food':food})
    return redirect('/home')

if __name__=='__main__':
    app.run(host='0.0.0.0',debug=True,port=8080)